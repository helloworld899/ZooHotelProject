import java.util.ArrayList;

public class Room01 {

    static ArrayList<Room> availableRooms = new ArrayList<Room>();

    /* Room room01 = new Room (01, 35, "Single bed", "yes", "Street view",
            "Yes", "No,", "basic room", 1);

     */


}
