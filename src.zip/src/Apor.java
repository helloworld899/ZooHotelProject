import java.util.ArrayList;

public class Apor {

    //  static ArrayList<Animal> species = new ArrayList<Animal>();

    /*
    Animal apor = new Animal("Ceasar", 20, "All", "Trumpet", "Dry dog-food");

     */
}
