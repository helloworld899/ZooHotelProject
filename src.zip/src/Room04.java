import java.util.ArrayList;

public class Room04 {

    static ArrayList<Room> availableRooms = new ArrayList<Room>();


    /* Room room04 = new Room (04, 60, "Two Single beds", "yes", "Balcony",
            "Yes", "Yes,", "Micro,fridge,",2);

     */





}


