import java.util.ArrayList;

public class Hästar {

    static ArrayList<Animal> species = new ArrayList<Animal>();

    public static void start() {

      /*  Animal horse = new Animal("Sugar", 4, "Hay", "neigh!!", "Silver");

       */


    }


}

