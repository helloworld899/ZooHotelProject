import java.util.ArrayList;

public class Room03 {

        static ArrayList<Room> availableRooms = new ArrayList<Room>();

     /*   Room room03 = new Room(03, 50, "Dubble bed", "Yes", "Street view",
                "Yes", "Yes,", "Micro, Fridge", 2);

      */

}

