import java.util.ArrayList;
import java.util.Scanner;

public class BookingSystem {
     ArrayList<room> rooms = new ArrayList<rooms>();


    public static void booking() {

        //ALl animals
        Animal elefanter = new Animal("Dumbo", 12, "Grass", "Trumpet", "Grey");
        speciesList.add(elefanter);

        Animal dogs = new Animal("Tom", 7, "All", "wuf wuf", "Dry dog-food");
        speciesList.add(dogs);

        Animal apor = new Animal("Ceasar", 20, "All", "Trumpet", "Dry dog-food");
        speciesList.add(apor);

        Animal horse = new Animal("Sugar", 4, "Hay", "neigh!!", "Silver");
        speciesList.add(horse);

        //All rooms
        Room room01 = new Room(01, 35, "Basic room with a singel bed and street view",null);

        Room room02 = new Room(02, 45, "Room with double bed",null);

        Room room03 = new Room(03, 50, "Room with double bed, fridge, micro and stuff", null);

        Room room04 = new Room(04, 60, "Room with two single bed and a spacious balcony and beautiful view", null);

        Room room05 = new Room(04, 70, " Dubble bed and sofa bed. Amazing sea view from the east side", null);


        boolean runProgram = true;
        while (runProgram) {
            printMenu();
            int dataInput = getUserInt();
            switch (dataInput) {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;

            }
        }
    }




        public static void printMenu () {
            System.out.println("Welcome");
            System.out.println("1. List of all rooms");
            System.out.println("1a: rooms available");
            System.out.println("xxxx");
            System.out.println("Search bookings");
            System.out.println("Add/");
        }


        public static String getUserString () {
            Scanner myScan = new Scanner(System.in);
            String userInput = myScan.nextLine();

            return userInput;


        }

        public static int getUserInt () {
            Scanner myScan = new Scanner(System.in);
            int userInput;

            while (true) {
                try {
                    userInput = Integer.parseInt(myScan.nextLine());
                    break;
                } catch (Exception e) {
                    System.out.println("Sorry, wrong input. Try again");
                }

            }
            return userInput;
        }



}



