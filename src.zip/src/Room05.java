import java.util.ArrayList;

public class Room05 {

    static ArrayList<Room> availableRooms = new ArrayList<Room>();

   /* Room room05 = new Room (04, 70, "Dubble bed and a sofa bed", "yes", "Balcony with sea view",
            "Yes", "Yes,", "Micro,fridge, safe deposit box, room service", 3);


    */

}
