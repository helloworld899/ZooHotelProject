import java.util.ArrayList;

public class Room02 {

    static ArrayList<Room> availableRooms = new ArrayList<Room>();

   /* Room room02 = new Room (02, 45, "Double bed", "Yes", "Street view",
            "Yes", "Yes,",  "Safe deposit box", 2);

    */

}



