public class Room {

    public int roomNr;
    public Animal guest;
    public int price;
    private String description;


    //Konstruktor
    public Room(int roomNr, int price, String description, Animal guest) {

        this.setRoomNr(roomNr);
        this.setPrice(price);
        this.setDescription(description);
        this.setGuest(guest);


    }

    public int getRoomNr(int roomNr) {
        return roomNr;
    }
    public void setRoomNr(int roomNr) {
        this.roomNr = roomNr;
    }

    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }







    public static String describe(){
        System.out.println("Comfortable rooms for everyone");
        return describe();
    }



    public static void available() {
        System.out.println(" This room is bookable");
    }

    public static void unavailable() {
        System.out.println(" This room is not bookable");
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Animal getGuest() {
        return guest;
    }

    public void setGuest(Animal guest) {
        this.guest = guest;
    }
}