public class Animal {
    private String name;
    private int age;
    private String eat;
    private String sound;
    private String favoritAktivitet;





    //Konstruktor
    public Animal (String name, int age, String eat, String sound, String favoritAktivitet) {

        this.setName(name);
        this.setAge(age);
        this.setEat(eat);
        this.setSound(sound);
        this.setFavoritAktivitet(favoritAktivitet);

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEat() {
        return eat;
    }

    public void setEat(String eat) {
        this.eat = eat;
    }

    public String getSound() {
        return sound;
    }

    public void setSound(String sound) {
        this.sound = sound;
    }


    public String getFavoritAktivitet() {
        return favoritAktivitet;
    }

    public void setFavoritAktivitet(String favoritAktivitet) {
        this.favoritAktivitet = favoritAktivitet;
    }


    //Methods
    public static void eat() {
        System.out.println("Now I'm eating my dinner");
    }

    public static void talk() {
        System.out.println("Hello my friend");
    }

    public static void run() {
        System.out.println("I'm running");
    }

}


