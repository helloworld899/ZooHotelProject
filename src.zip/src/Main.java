public class Main {
    public static void main (String[] args) {

            BookingSystem hotel = new BookingSystem();
            hotel.booking();
    }
}
