import java.util.ArrayList;

//public class Hundar {



  //  static ArrayList<Animal> speciesList = new ArrayList<Animal>();


    //  public static void species() {

       /* Animal dogs = new Animal("Tom", 7, "All", "wuf wuf", "Dry dog-food");
        speciesList.add(dogs);


        */

