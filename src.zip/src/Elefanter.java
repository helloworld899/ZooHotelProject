import java.util.ArrayList;

public class Elefanter {

   //  static ArrayList<Animal> speciesList = new ArrayList<Animal>();


   //  public static void species() {

    /*  Animal elefanter = new Animal("Dumbo", 12, "Grass", "Trumpet", "Grey");
      speciesList.add(elefanter);

     */


   }




